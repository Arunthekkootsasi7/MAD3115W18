//
//  BookCell.swift
//  day9
//
//  Created by MacStudent on 2018-03-02.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class BookCell: UICollectionViewCell {
    
    @IBOutlet weak var lblBooktitle: UILabel!
    @IBOutlet weak var imgBook: UIImageView!
    
   
    
}
