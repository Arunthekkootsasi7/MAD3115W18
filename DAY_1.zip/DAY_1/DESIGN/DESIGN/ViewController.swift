//
//  ViewController.swift
//  DESIGN
//
//  Created by MacStudent on 2018-02-20.
//  Copyright © 2018 Arun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var txtbox: UITextField!
    
    
    @IBOutlet weak var lblEmail: UILabel!
    
    @IBAction func connect(_ sender: Any) {
    }
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
       
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

// alert creation
/*
 let infoAlert =
    UIAlertController(title: "User Information", message: txtEmail.text!, prefferedStyle: .alert)

infoAlert.addAddiction(UIAlertaction(title: "Cancel", style: .cancel, handler: nil))
*/

// alert and actionsheet is used to create an alert box
