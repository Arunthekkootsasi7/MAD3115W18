//
//  supportVC.swift
//  MyParker
//
//  Created by Sreejith Thrivikraman on 2018-03-06.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import UIKit
import MessageUI

class supportVC: UIViewController,MFMailComposeViewControllerDelegate {

    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // code to open an Email application
    @IBAction func sendEmail(_ sender: Any)
    
    {
        let mailComposeViewController = configureMailController()
        if MFMailComposeViewController.canSendMail()
        {
            self.present(mailComposeViewController, animated: true, completion: nil)
        }
        else
        {
            showMailError()
        }
    }
    
    // code to make a phone call
    @IBAction func makePhoneCall(_ sender: Any)
    {
        
        let url = URL(string: "tel://+14379986008")
        
        if UIApplication.shared.canOpenURL(url!){
            if #available(iOS 10, *)
            {
                UIApplication.shared.open(url!)
            }
            else
            {
                UIApplication.shared.openURL(url!)
            }
        }
    }
    
    func configureMailController() -> MFMailComposeViewController
    {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        mailComposerVC.setToRecipients(["mail.sreejith.23@gmail.com"])
        mailComposerVC.setSubject("MyParker customer Inquiry : ")
        mailComposerVC.setMessageBody("Hi,", isHTML: false)
        
        return mailComposerVC
      
    }
    
    func showMailError() {
        let sendMailErrorAlert = UIAlertController(title: "Could not send email", message: "Your device could not send email", preferredStyle: .alert)
        let dismiss = UIAlertAction(title: "Ok", style: .default, handler: nil)
        sendMailErrorAlert.addAction(dismiss)
        self.present(sendMailErrorAlert, animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }

}
