//
//  TVC.swift
//  MyParker
//
//  Created by Sreejith Thrivikraman on 2018-03-07.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import UIKit

class TVC: UITableViewController
{
    var invoiceDate =  ""
    var  parking_lot =  ""
    var  car_manu =  ""
    var  paymentMethod =  ""
    var car_plate_no =  ""
    var parking_time = ""
    var parking_spot =  ""
    var time = ""
    var totalAmount = ""
    
    var car_color = ""
    
    
     var plistArray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.fetchValuesFromPlist()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.plistArray.count
    }

 
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        // Configure the cell...

        let dictCar = plistArray[indexPath.row] as! NSMutableDictionary
        cell.textLabel?.text = dictCar.value(forKey: "date") as? String
        
        return cell
    }
  
    
    func fetchValuesFromPlist(){
        if let filePath = Bundle.main.path(forResource: "data_bill", ofType: "plist")
        {
            //get an array representation of plist
            plistArray = NSMutableArray(contentsOfFile: filePath)!
            print("plistArray \(plistArray)")
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
        let data = plistArray[indexPath.row] as! NSMutableDictionary
       
  
        
                invoiceDate   =  (data.value(forKey: "date") as? String)!
                parking_lot   =  (data.value(forKey: "lot") as? String)!
                car_manu      =  (data.value(forKey: "manu") as? String)!
                paymentMethod =  (data.value(forKey: "payment") as? String)!
                car_plate_no  =  (data.value(forKey: "plate") as? String)!
                parking_time  =  (data.value(forKey: "ptime") as? String)!
                parking_spot  =  (data.value(forKey: "spot") as? String)!
                time          =  (data.value(forKey: "time") as? String)!
                car_color     =  (data.value(forKey: "color") as? String)!
                totalAmount   =  (data.value(forKey: "amt") as? String)!
        
              
        //new.createInvoiceAsHTML()
        
        
        let listSB = UIStoryboard(name: "Main", bundle: nil)
        let listVC = listSB.instantiateViewController(withIdentifier: "receipt") as! receipt_view
        listVC.car_manu = car_manu
        listVC.invoiceDate = invoiceDate
        listVC.car_plate_no = car_plate_no
        listVC.parking_lot = parking_lot
        listVC.paymentMethod = paymentMethod
        listVC.parking_time = parking_time
        listVC.parking_spot = parking_spot
        listVC.time         =  time
        listVC.car_color =  car_color
        listVC.totalAmount = totalAmount
        
        
        self.navigationController?.pushViewController(listVC, animated: true)
      
    }
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        var DestViewControl : Home_ViewController = segue.destination as! Home_ViewController
//        DestViewControl.flag = true
//    }
    
    
    
  
}













