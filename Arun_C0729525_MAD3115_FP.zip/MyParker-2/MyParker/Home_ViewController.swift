//
//  Home_ViewController.swift
//  MyParker
//
//  Created by Sreejith Thrivikraman on 2018-02-22.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import UIKit

class Home_ViewController: UIViewController {

    var flag = false
    var user_name = ""
    
    @IBOutlet weak var label_user_name: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        label_user_name.text = user_name
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewDidAppear(_ animated: Bool)                   // code to create a segue directly to logn screen
    
    {
        if (flag == false)
        {
        self.performSegue(withIdentifier: "login_segue", sender: self)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
