//
//  parkingReceipt.swift
//  MyParker
//
//  Created by Sreejith Thrivikraman on 2018-03-05.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import UIKit

class parkingReceipt: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource
{
    
    

    @IBOutlet weak var park_time_label: UILabel!
    @IBOutlet weak var manufaturer_picker: UIPickerView!
    @IBOutlet weak var manu_image: UIImageView!
    @IBOutlet weak var payment_picker: UIPickerView!
    @IBOutlet weak var label_amount: UILabel!
    @IBOutlet weak var date_label: UILabel!
    @IBOutlet weak var time_label: UILabel!
   
    
    @IBOutlet weak var car_color_label: UITextField!
    @IBOutlet weak var txt_car_plate_no: UITextField!
    @IBOutlet weak var txt_lot_number: UITextField!
    @IBOutlet weak var txt_spot_number: UITextField!
    
    
    let manufacturers = ["Audi","BMW","Ford","Lamborghini","Hyundai","Volkswagen"]
    let manufacture_images  = ["audi.png","BMW.png","ford.png","lambo.png","hyundai.png","volks.png"]
    let payment_method  = ["Credit","Debit","Internet Banking"]
    var parked_time : String = ""
    var result = ""
    var current_time = ""
    var store_manu = ""
    var store_paymnt = ""
   
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //add data in picker
        self.manufaturer_picker.delegate = self
        self.manufaturer_picker.dataSource = self
        self.payment_picker.delegate = self
        self.payment_picker.dataSource = self
        park_time_label.text = self.parked_time
        
        // pulling current date and time.
        let date = Date()
        let formatter = DateFormatter()
        let time_formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        time_formatter.dateFormat = "HH:mm:ss"
        var result = formatter.string(from: date)
        var current_time = time_formatter.string(from: date)
        date_label.text = result
        time_label.text = current_time
        label_amount.text = (String)(Int(arc4random_uniform(50)))
    }

    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        var temp_count = 1
        if pickerView == manufaturer_picker
        {
            temp_count = self.manufacturers.count
            
        } else
            
        if pickerView == payment_picker
        {
                //pickerView2
                temp_count = self.payment_method.count
        }
        
        return temp_count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> (String?)
        
    {
        var temp_string = ""
        var temp_image_name : String = ""
        if pickerView == manufaturer_picker
        {
            temp_string = self.manufacturers[row]
            manu_image.image = UIImage(named: manufacture_images[row])   // loading the image  // storing product number
            store_manu = self.manufacturers[row]
        } else if pickerView == payment_picker
            
        {
            //pickerView2
            temp_string = self.payment_method[row]
            store_paymnt = self.payment_method[row]

            
        }
        
        return temp_string
        
    }
    
    // code to to save the data to plist.
    @IBAction func button_bill_me(_ sender: Any)
    {
        var export_object = templateClass()
       
        
        export_object.invoice_date   = date_label.text!
        export_object.invoice_time   = time_label.text!
        export_object.parking_time   = self.parked_time
        export_object.manu_name      = store_manu
        export_object.car_color      = car_color_label.text!
        export_object.plate_number   = txt_car_plate_no.text!
        export_object.lot_number     = txt_lot_number.text!
        export_object.spot_number    = txt_spot_number.text!
        export_object.payment_method = store_paymnt
        export_object.paymnt_amt     = label_amount.text!
        
        export_object.get_data(object: export_object)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        var DestViewControl : PreviewViewController = segue.destination as! PreviewViewController
       
        DestViewControl.invoiceDate = date_label.text!
        DestViewControl.time = date_label.text!
        DestViewControl.totalAmount = (String)(arc4random_uniform(10))
        DestViewControl.paymentMethod = store_paymnt
        DestViewControl.car_manu = store_manu
        DestViewControl.parking_lot = txt_lot_number.text!
        DestViewControl.parking_spot = txt_spot_number.text!
        DestViewControl.parking_time = self.parked_time
        DestViewControl.car_color = car_color_label.text!
        DestViewControl.car_plate_no = txt_car_plate_no.text!
        
    }
    
    
    

}
