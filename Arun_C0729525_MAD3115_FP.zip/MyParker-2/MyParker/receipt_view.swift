//
//  receipt_view.swift
//  MyParker
//
//  Created by Sreejith Thrivikraman on 2018-03-07.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import UIKit

class receipt_view: UIViewController
{
    
    var invoiceInfo: [String: AnyObject]!
    
    @IBOutlet weak var pdf_view: UIWebView!
    var invoiceComposer: invoice_composer!
    var HTMLContent: String!
    
    
    
    
    
    var invoiceDate = ""
    var time = ""
    var totalAmount = ""
    var paymentMethod = ""
    var car_manu = ""
    var parking_lot = ""
    var parking_spot = ""
    var parking_time = ""
    var car_color = ""
    var car_plate_no = ""
    var invoiceNumber = (String)(Int(arc4random_uniform(550)))

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        createInvoiceAsHTML()
        
        
    }

    func createInvoiceAsHTML()
    {
        var temp_name = UserDefaults.standard.value(forKey: "first_name_dat") as! String
        var temp_email = UserDefaults.standard.value(forKey: "email_dat") as! String
        
        var  senderInfo = "Name : \(temp_name)<br>E-mail : \(temp_email) <br>Car Plate # : \(car_plate_no)<br>Manufacturer : \(car_manu)<br> Car Color : \(car_color)"
        
        invoiceComposer = invoice_composer()
        //        let store =  invoiceComposer.renderInvoice(invoiceNumber:invoiceNumber, invoiceDate: invoiceDate, recipientInfo: invoiceComposer.senderInfo, totalAmount: totalAmount, car_plate_no: car_plate_no, car_manu: car_manu, car_color: car_color)
        //
        if let invoiceHTML = invoiceComposer.renderInvoice(invoiceNumber:invoiceNumber, invoiceDate: invoiceDate, recipientInfo: senderInfo, totalAmount: totalAmount, car_plate_no: car_plate_no, car_manu: car_manu, car_color: car_color, paymnt_method: paymentMethod, invoice_time: time, parking_lot: parking_lot, parking_spot: parking_spot, parking_time: parking_time)
        {
            
            pdf_view.loadHTMLString(invoiceHTML, baseURL: NSURL(string: invoiceComposer.pathToInvoiceHTMLTemplate!)! as URL)
            HTMLContent = invoiceHTML
        }
        
    }
    
    func viewWillAppear(animated: Bool)
    {
        super.viewWillAppear(animated)
        
        createInvoiceAsHTML()
    }
    
    

   

}
