//
//  Map_View.swift
//  MyParker
//
//  Created by Sreejith Thrivikraman on 2018-03-03.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation



class Map_View: UIViewController,CLLocationManagerDelegate,UISearchBarDelegate {

   
    
    @IBOutlet weak var searchbar_map: UISearchBar!
    
    
 
    @IBOutlet weak var Map_View: MKMapView!
    

    
    let manager = CLLocationManager()
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let location =  locations[0]
        let span = MKCoordinateSpanMake(0.05, 0.05)
        
        
        let center = location.coordinate
        let region : MKCoordinateRegion  = MKCoordinateRegionMake(center, span)
        Map_View.setRegion(region, animated: true)
        self.Map_View.showsUserLocation = true
        
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        manager.delegate = self
        searchbar_map.delegate = self
        
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
        
        
        
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        searchbar_map.resignFirstResponder()
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(searchbar_map.text!)
        { (placemarks: [CLPlacemark]?,error :Error?) in
            if  error == nil
            {
                let placemark = placemarks?.first
                let annotation = MKPointAnnotation()
                annotation.coordinate = (placemark?.location?.coordinate)!
                
                annotation.title = self.searchbar_map.text!
                self.Map_View.addAnnotation(annotation)
                self.Map_View.selectAnnotation(annotation, animated: true)
            } else
            {
                print(error?.localizedDescription ?? "error")
            }
            }
    }
    
    
    override func didReceiveMemoryWarning()
    
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
