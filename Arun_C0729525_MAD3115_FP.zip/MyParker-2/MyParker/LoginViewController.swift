//
//  LoginViewController.swift
//  MyParker
//
//  Created by Sreejith Thrivikraman on 2018-02-22.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation
import UIKit

class LoginViewController : UIViewController
{
   
    
    @IBOutlet weak var Label_login: UILabel!
    
    @IBOutlet weak var Label_password: UILabel!
    
    @IBOutlet weak var text_username: UITextField!
    
    @IBOutlet weak var text_password: UITextField!
    
    
    public var from_location: String = ""
    
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "iPhone-6-wallpaper-03-576x1024.jpg")!)
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // clear_fields function will clear the username and password fields.
    func clear_fields()
    {
        text_username.text = ""
        text_password.text = ""
    }
    
    
    @IBAction func Button_Login(_ sender: UIButton)              // code to cross-check the user name and password.
    {
        
        let name = text_username.text
        let Password = text_password.text
        let temp_name = UserDefaults.standard.value(forKey: "first_name_dat") as? String
        let temp_pass = UserDefaults.standard.value(forKey: "password_dat") as? String
        
        
        if (temp_name !=  nil)
        {
            if (name == temp_name && Password == temp_pass)
            {
                from_location = "Login"
                let infoAlert_success = UIAlertController(title: "Login Sucessful", message: "You are authenticated", preferredStyle: .alert)
            
           
                infoAlert_success.addAction(UIAlertAction(title: "Okay", style: .default, handler: {(action:UIAlertAction) in
                    self.performSegue(withIdentifier: "home_segue", sender: self)
                }))
                self.present(infoAlert_success, animated: true, completion: nil)
            
            }
        
            else
            {
                let infoAlert_error = UIAlertController(title: "Login Failed !!", message: "Please try again !", preferredStyle: .alert)
            
                infoAlert_error.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
            
                self.present(infoAlert_error, animated: true, completion: nil)
            
                clear_fields()                                    // clear_fields function will clear the username and password field once the login attempt results in a failure.
            }
        
        }
        else
        {
            let infoAlert_error = UIAlertController(title: "No user is registered !", message: "Please Register to start using the App !", preferredStyle: .alert)
            
            infoAlert_error.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
            
            self.present(infoAlert_error, animated: true, completion: nil)
        }
    
    }
 
    
    // code to dismiss the login screen and direct control to registration screen.
    @IBAction func Button_Register(_ sender: UIButton)
    
    {
        from_location = "Register"
        self.dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        switch from_location
        {
        case "Login":
                        var DestViewControl : Home_ViewController = segue.destination as! Home_ViewController
                        DestViewControl.flag = true
                        DestViewControl.user_name = text_username.text!
         
        case "Register" : break
        default:
            let infoAlert_error = UIAlertController(title: "From_location Error", message: "Debug Location Error !", preferredStyle: .alert)
            
            infoAlert_error.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
            
            self.present(infoAlert_error, animated: true, completion: nil)
        }
        
    }
}
