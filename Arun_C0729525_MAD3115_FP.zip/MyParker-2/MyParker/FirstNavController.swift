//
//  FirstNavController.swift
//  MyParker
//
//  Created by Sreejith Thrivikraman on 2018-02-22.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation
import UIKit

class FirstNavController: UINavigationController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
