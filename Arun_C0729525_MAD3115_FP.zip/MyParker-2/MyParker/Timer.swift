//
//  Timer.swift
//  MyParker
//
//  Created by Sreejith Thrivikraman on 2018-03-05.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import UIKit

class Timer: UIViewController {

    @IBOutlet weak var seconds: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
      var timer = Timer.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func runTimer()
    {
        timer = Timer.sch
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
