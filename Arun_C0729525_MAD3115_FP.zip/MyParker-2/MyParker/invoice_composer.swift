//
//  invoice_composer.swift
//  MyParker
//
//  Created by Sreejith Thrivikraman on 2018-03-05.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import UIKit

class invoice_composer: NSObject

{
    override init()
    {
        super.init()
    }
    
    var temp_name : String = ""
    
    let pathToInvoiceHTMLTemplate = Bundle.main.path(forResource: "invoice", ofType: "html")
    
    var object_receipt = parkingReceipt()
    var time = ""
    var senderInfo = ""
    var paymentMethod = ""
    
    var logoImageURL = "audi.png"
    
    
    var invoiceNumber: String = "1234"
    var invoiceDate : String = ""
    var recipientInfo: String = "MyParker Inc."
    var totalAmount : String = ""
    var pdfFilename: String!
    var parking_time : String = ""
    var parking_lot : String = ""
    var parking_spot : String = ""
    var car_color : String = ""
    var car_plate_no : String = ""
    var car_manu : String = ""
    
    func renderInvoice(invoiceNumber: String, invoiceDate: String, recipientInfo: String,totalAmount: String,car_plate_no : String, car_manu : String,car_color: String, paymnt_method: String,invoice_time: String,parking_lot: String,parking_spot: String,parking_time: String) -> String!
    {
        self.invoiceNumber = invoiceNumber
        temp_name = UserDefaults.standard.value(forKey: "first_name_dat") as! String
        var temp_email = UserDefaults.standard.value(forKey: "email_dat") as! String
       
        
        
        senderInfo = "Name : \(temp_name)<br>E-mail : \(temp_email) <br>Car Plate # : \(car_plate_no)<br>Manufacturer : \(car_manu)<br> Car Color : \(car_color)"
        
        var HTMLContent :String = ""
        do {
            // Load the invoice HTML template code into a String variable.
            HTMLContent = try String(contentsOfFile: pathToInvoiceHTMLTemplate!)
            
            // Replace all the placeholders with real values except for the items.
            // The logo image.
            HTMLContent = HTMLContent.replacingOccurrences(of: "#LOGO_IMAGE#", with: logoImageURL)
            
            // Invoice number.
            HTMLContent = HTMLContent.replacingOccurrences(of: "#INVOICE_NUMBER#", with: invoiceNumber)
            
            // Invoice date.
            HTMLContent = HTMLContent.replacingOccurrences(of : "#INVOICE_DATE#", with: invoiceDate)
            
            // Due date (we leave it blank by default).
            HTMLContent = HTMLContent.replacingOccurrences(of : "#TIME#", with: invoice_time)
            
            // Sender info.
            HTMLContent = HTMLContent.replacingOccurrences(of :"#SENDER_INFO#", with: senderInfo)
            
            // Recipient info.
            HTMLContent = HTMLContent.replacingOccurrences(of :"#RECIPIENT_INFO#", with: "")
            
            // Payment method.
                HTMLContent = HTMLContent.replacingOccurrences(of :"#PAYMENT_METHOD#", with: paymnt_method)
            
            // Total amount.
                HTMLContent = HTMLContent.replacingOccurrences (of : "#TOTAL_AMOUNT#", with: totalAmount)
                HTMLContent = HTMLContent.replacingOccurrences (of : "#PARKINGLOT#", with: parking_lot)
                HTMLContent = HTMLContent.replacingOccurrences (of : "#PARKINGSPOT#", with: parking_spot)
                HTMLContent = HTMLContent.replacingOccurrences (of : "#TOTALTIME#", with: parking_time)
            
           
            
            
            
        }
        catch {
            print("Unable to open and use HTML template files.")
        }
        
        return HTMLContent
        
        
        
    }
    

}



