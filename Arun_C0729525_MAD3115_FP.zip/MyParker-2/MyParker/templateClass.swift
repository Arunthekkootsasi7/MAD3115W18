//
//  templateClass.swift
//  MyParker
//
//  Created by Sreejith Thrivikraman on 2018-03-07.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation
class templateClass

{
    var invoice_date = ""
    var invoice_time = ""
    var parking_time = ""
    var manu_name = ""
    var car_color = ""
    var plate_number = ""
    var lot_number = ""
    var spot_number = ""
    var payment_method = ""
    var paymnt_amt = ""
    var DB_objects = [templateClass]()
    
    // function to store the data to list
    func get_data(object : templateClass)
    {
         var temp_object = templateClass()
         temp_object.invoice_date   = object.invoice_date
         temp_object.invoice_time   = object.invoice_time
         temp_object.parking_time   = object.parking_time
         temp_object.manu_name      = object.manu_name
         temp_object.car_color      = object.car_color
         temp_object.plate_number   = object.plate_number
         temp_object.lot_number     = object.lot_number
         temp_object.spot_number    = object.spot_number
         temp_object.payment_method = object.payment_method
         temp_object.paymnt_amt     = object.paymnt_amt
        
         writePropertyList(object : temp_object)
        
        
    }
    
    func writePropertyList(object : templateClass)
    {
        let data = NSMutableDictionary()
        data["date"] = self.invoice_date
        data["time"] = self.invoice_time
        data["ptime"] = self.parking_time
        data["manu"] = self.manu_name
        data["color"] = self.car_color
        data["plate"] = self.plate_number
        data["lot"] = self.lot_number
        data["spot"] = self.spot_number
        data["payment"] = self.payment_method
        data["amt"] = self.paymnt_amt
        
        
        if let plistPath = Bundle.main.path(forResource: "data_bill", ofType: "plist"){
            let plist = NSMutableArray(contentsOfFile: plistPath)
            plist?.add(data)
            if (plist?.write(toFile: plistPath, atomically: true))!{
                print("list>>>>>> : \(String(describing: plist))")
            }
            
        }else
        {
            print("Unable to locate plist file")
        }
       
       
        
    }
    
   
    
}
